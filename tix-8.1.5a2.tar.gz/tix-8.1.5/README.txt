
   Tix 8.1.4 for Tcl 8.0, 8.1, 8.2 or 8.3
   
                       Tix Documentation Master Index
                                      
   This file is the master index of all the documentation included in
   this package. For additional information about Tix, please visit the
   Tix Home Page at [1]http://tix.sourceforge.net or join the mailing
   lists there. (Note that http://www.xpi.com http://tix.mne.com
   mentioned in earlier releases of Tix no longer exists).
   
     * ABOUT.txt [2]A brief description of Tix.
     * docs/Release.html [3]Release notes on this version of Tix.
     * docs/Install.html [4]Compiling and installing Tix .
     * docs/html/TixUser/TixUser.html> [5]Tix Users's Guide.
     * Programming with Tix:
          + [6]Tix Programmer's Guide.
          + [7]Using Tix Stand Alone Modules (SAM).
     * docs/FAQ.html [8]The Tix Frequent Asked Questions.
     * docs/Changes.html [9]Changes made to Tix since the previous
       release.
     * man/index.html [10]Programmer's Reference Manual.
       
   Versions of Tcl/Tk prior to 8.0 are no longer supported.
   
   This release should work with Tcl 8.4, but it is not yet supported. To
   contribute patches, see http://tix.sourceforge.net.

References

   1. http://tix.sourceforge.net/
   2. ABOUT.html
   3. docs/Release.html
   4. docs/Install.html
   5. docs/html/TixUser/TixUser.html
   6. docs/html/TixBook/TixBook.html
   7. docs/SAModule.txt
   8. docs/FAQ.html
   9. docs/Changes.html
  10. man/index.html
