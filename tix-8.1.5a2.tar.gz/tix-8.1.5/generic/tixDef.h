
/*	$Id: tixDef.h,v 1.2.2.1 2002/12/17 08:01:01 idiscovery Exp $	*/

/*
 * tixdef.h --
 *
 *	This file defines the defaults for all options for all of
 *	the Tix widgets.
 *
 * Copyright (c) 1996, Expert Interface Technologies
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */

#ifndef TIX_DEFAULT
#define TIX_DEFAULT

/*
 * Include the defaults of the TK distriburion
 */
#ifndef _DEFAULT
#include <default.h>
#endif

#if defined(__WIN32__) || defined(_WIN32)
#   include <tixWinDefault.h>
#else
#   if defined(MAC_TCL)
#	include <tixMacDefault.h>
#   else
#	include <tixUnixDefault.h>
#   endif
#endif

#endif /* TIX_DEFAULT */
